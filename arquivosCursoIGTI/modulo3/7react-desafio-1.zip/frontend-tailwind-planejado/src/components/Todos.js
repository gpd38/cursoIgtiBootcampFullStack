import React from 'react';

export default function Todos({ children }) {
  return <div className="mt-4 p-2 border rounded-lg">{children}</div>;
}
