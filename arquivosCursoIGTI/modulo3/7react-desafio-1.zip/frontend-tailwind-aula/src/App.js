import TodosPage from './pages/TodosPage';

export default function App() {
  return <TodosPage />;
}
